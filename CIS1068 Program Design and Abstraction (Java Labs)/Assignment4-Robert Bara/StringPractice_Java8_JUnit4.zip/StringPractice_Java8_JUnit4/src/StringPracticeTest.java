import static org.junit.Assert.*;

import org.junit.Test;

public class StringPracticeTest {

    @Test
    public void testIsPunct() {
      assertTrue(StringPractice.isPunct('.'));
      assertTrue(StringPractice.isPunct(';'));
      assertTrue(StringPractice.isPunct('?'));
      assertTrue(StringPractice.isPunct('\''));
      assertTrue(StringPractice.isPunct(','));
      assertTrue(StringPractice.isPunct(':'));
      assertTrue(StringPractice.isPunct('!'));
      assertFalse(StringPractice.isPunct(' '));
      assertFalse(StringPractice.isPunct('_'));
      assertFalse(StringPractice.isPunct('a'));
      assertFalse(StringPractice.isPunct('\t'));
      assertFalse(StringPractice.isPunct('\n'));
    }

    @Test
    public void testNumPunct() {
      assertEquals(StringPractice.numPunct("cheesy poofs"), 0);
      assertEquals(StringPractice.numPunct(""), 0);
      assertEquals(StringPractice.numPunct("!"), 1);
      assertEquals(StringPractice.numPunct("! "), 1);
      assertEquals(StringPractice.numPunct("! "), 1);
      assertEquals(StringPractice.numPunct(" !"), 1);
      assertEquals(StringPractice.numPunct(".!"), 2);
      assertEquals(StringPractice.numPunct(". !"), 2);
      assertEquals(StringPractice.numPunct("There's always money in the banana stand."), 2);
    }

    @Test
    public void testNumPunctStringInt() {
      assertEquals(StringPractice.numPunct("cheesy poofs", 4), 0);
      assertEquals(StringPractice.numPunct("", 1), 0);
      assertEquals(StringPractice.numPunct("!", 0), 1);
      assertEquals(StringPractice.numPunct("!", 1), 0);
      assertEquals(StringPractice.numPunct("! ", 1), 0);
      assertEquals(StringPractice.numPunct("! ", 0), 1);
      assertEquals(StringPractice.numPunct(" !", 0), 1);
      assertEquals(StringPractice.numPunct(".!", 0), 2);
      assertEquals(StringPractice.numPunct(".!", 1), 1);
      assertEquals(StringPractice.numPunct(".!", 2), 0);
      assertEquals(StringPractice.numPunct(". !", 0), 2);
      assertEquals(StringPractice.numPunct(". !", 1), 1);
      assertEquals(StringPractice.numPunct(". !", 2), 1);
      assertEquals(StringPractice.numPunct(". !", 3), 0);
      assertEquals(StringPractice.numPunct("There's always money in the banana stand.", 5), 2);
      assertEquals(StringPractice.numPunct("There's always money in the banana stand.", 6), 1);
    }

    @Test
    public void testIndexOfFirstPunctString() {
      assertEquals(StringPractice.indexOfFirstPunct("cheesy poofs"), -1);
      assertEquals(StringPractice.indexOfFirstPunct(""), -1);
      assertEquals(StringPractice.indexOfFirstPunct("!"), 0);
      assertEquals(StringPractice.indexOfFirstPunct(" !"), 1);
      assertEquals(StringPractice.indexOfFirstPunct(". !"), 0);
      assertEquals(StringPractice.indexOfFirstPunct("There's always money in the banana stand."), 5);
    }


    @Test
    public void testIndexOfFirstPunctStringInt() {
      assertEquals(StringPractice.indexOfFirstPunct("cheesy poofs", 4), -1);
      assertEquals(StringPractice.indexOfFirstPunct("cheesy poofs", 0), -1);
      assertEquals(StringPractice.indexOfFirstPunct("", 1), -1);
      assertEquals(StringPractice.indexOfFirstPunct("!", 0), 0);
      assertEquals(StringPractice.indexOfFirstPunct("!", 1), -1);
      assertEquals(StringPractice.indexOfFirstPunct("! ", 1), -1);
      assertEquals(StringPractice.indexOfFirstPunct("! ", 0), 0);
      assertEquals(StringPractice.indexOfFirstPunct("! ", 1), -1);
      assertEquals(StringPractice.indexOfFirstPunct("! ", 2), -1);
      assertEquals(StringPractice.indexOfFirstPunct(" !", 0), 1);
      assertEquals(StringPractice.indexOfFirstPunct(".!", 0), 0);
      assertEquals(StringPractice.indexOfFirstPunct(".!", 1), 1);
      assertEquals(StringPractice.indexOfFirstPunct(".!", 2), -1);
      assertEquals(StringPractice.indexOfFirstPunct(". !", 0), 0);
      assertEquals(StringPractice.indexOfFirstPunct(". !", 1), 2);
      assertEquals(StringPractice.indexOfFirstPunct(". !", 2), 2);
      assertEquals(StringPractice.indexOfFirstPunct(". !", 3), -1);
      assertEquals(StringPractice.indexOfFirstPunct("There's always money in the banana stand.", 0), 5);
      assertEquals(StringPractice.indexOfFirstPunct("There's always money in the banana stand.", 5), 5);
      assertEquals(StringPractice.indexOfFirstPunct("There's always money in the banana stand.", 6), 40);
    }

    @Test
    public void testIndexOfLastPunct() {
      assertEquals(StringPractice.indexOfLastPunct("cheesy poofs"), -1);
      assertEquals(StringPractice.indexOfLastPunct(""), -1);
      assertEquals(StringPractice.indexOfLastPunct("!"), 0);
      assertEquals(StringPractice.indexOfLastPunct(" !"), 1);
      assertEquals(StringPractice.indexOfLastPunct(". !"), 2);
      assertEquals(StringPractice.indexOfLastPunct("There's always money in the banana stand."), 40);
    }

    @Test
    public void testSubstitute() {
      assertEquals(StringPractice.substitute("apple", 'a', 'A'), "Apple");
      assertEquals(StringPractice.substitute("apple", 'a', 'a'), "apple");
      assertEquals(StringPractice.substitute("apple", ' ', 'a'), "apple");
      assertEquals(StringPractice.substitute("apple", 'a', ' '), " pple");
      assertEquals(StringPractice.substitute("apple", 'e', 'E'), "applE");
      assertEquals(StringPractice.substitute("apple", ' ', 'e'), "apple");
      assertEquals(StringPractice.substitute("apple", 'e', ' '), "appl ");
      assertEquals(StringPractice.substitute("apple", 'p', ' '), "a  le");
    }

    @Test
    public void testSubstitutePunct() {
      assertEquals(StringPractice.substitutePunct("cheesy poofs"), "cheesy poofs");
      assertEquals(StringPractice.substitutePunct(""), "");
      assertEquals(StringPractice.substitutePunct("!"), " ");
      assertEquals(StringPractice.substitutePunct("! "), "  ");
      assertEquals(StringPractice.substitutePunct(" !"), "  ");
      assertEquals(StringPractice.substitutePunct(".!"), "  ");
      assertEquals(StringPractice.substitutePunct(". !"), "   ");
      assertEquals(StringPractice.substitutePunct("There's always money in the banana stand."),
                   "There s always money in the banana stand ");
    }

    @Test
    public void testWithoutPunct() {
      assertEquals(StringPractice.withoutPunct("cheesy poofs"), "cheesy poofs");
      assertEquals(StringPractice.withoutPunct(""), "");
      assertEquals(StringPractice.withoutPunct("!"), "");
      assertEquals(StringPractice.withoutPunct("! "), " ");
      assertEquals(StringPractice.withoutPunct(" !"), " ");
      assertEquals(StringPractice.withoutPunct(".!"), "");
      assertEquals(StringPractice.withoutPunct(". !"), " ");
      assertEquals(StringPractice.withoutPunct("There's always money in the banana stand."),
                   "Theres always money in the banana stand");
    }

    @Test
    public void testFoundIn() {
      assertFalse(StringPractice.foundIn("cheesy poofs", '.'));
      assertFalse(StringPractice.foundIn("cheesy poofs", 'q'));
      assertFalse(StringPractice.foundIn("", '.'));
      assertFalse(StringPractice.foundIn(" ", '.'));
      assertTrue(StringPractice.foundIn("cheesy poofs", 's'));
      assertTrue(StringPractice.foundIn("cheesy poofs", ' '));
      assertTrue(StringPractice.foundIn(" ", ' '));
    }

    @Test
    public void testContainsNone() {
      assertTrue(StringPractice.containsNone("cheesy poofs", "aiuAEIOU"));
      assertFalse(StringPractice.containsNone("cheesy poofs", "abcde"));
      assertFalse(StringPractice.containsNone("cheesy poofs", "ABCDE "));
      assertTrue(StringPractice.containsNone("", "abcde "));
    }

    @Test
    public void testOnlyPunct() {
      assertFalse(StringPractice.onlyPunct("!cheesy poofs"));
      assertFalse(StringPractice.onlyPunct("cheesy poofs"));
      assertFalse(StringPractice.onlyPunct("!,!?:,abc"));
      assertTrue(StringPractice.onlyPunct("!"));
      assertTrue(StringPractice.onlyPunct("!,!?:,"));
    }

    @Test
    public void testNoPunct() {
      assertFalse(StringPractice.noPunct("!cheesy poofs"));
      assertFalse(StringPractice.noPunct("cheesy! poofs!"));
      assertFalse(StringPractice.noPunct("!,!?:,abc"));
      assertTrue(StringPractice.noPunct("Four score"));
      assertTrue(StringPractice.noPunct(" "));
      assertTrue(StringPractice.noPunct(""));
    }
}
